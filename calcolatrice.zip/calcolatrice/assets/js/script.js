var finale = document.getElementById('text');

function calcola(numero){
    finale.value += numero;
};

function risultato() {
    finale.value = eval(finale.value);
};

function ripristina() {
    finale.value = " ";
};

function cancella() {
    finale.value = finale.value.slice(0,-1);
};